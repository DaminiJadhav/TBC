package com.truckbhejob2b.truckbhejocustomer.Utils;

import android.content.Context;

public class UpdateFcm {

    public static void updateFcm(Context mContext){

    }
}
