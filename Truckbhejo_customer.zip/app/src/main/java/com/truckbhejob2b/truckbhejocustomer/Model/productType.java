package com.truckbhejob2b.truckbhejocustomer.Model;

public class productType {
    String productId;
    String productType;

    public productType() {
        this.productId = productId;
        this.productType = productType;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }
}
