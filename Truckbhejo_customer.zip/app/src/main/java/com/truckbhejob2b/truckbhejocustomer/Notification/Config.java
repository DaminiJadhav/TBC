package com.truckbhejob2b.truckbhejocustomer.Notification;

public class Config {

    public static final String ANDROID_CHANNEL_ID = "TBC";


    public static final String ANDROID_CHANNEL_NAME = "CUSTOMER_ID";
    public static final String PUSH_NOTIFICATION ="PUSH" ;
    public static final String PUSH_ID ="id" ;
    public static final String PUSH_TITLE = "title";
    public static final String PUSH_ACTION = "action";
    public static final String PUSH_TYPE = "type";
    public static final String PUSH_ORDER_ID="orderId";
    public static final String PUSH_COMPANY_ID="companyId";

    public static final String ACTION = "action";

}
