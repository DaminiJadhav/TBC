package com.truckbhejob2b.truckbhejocustomer.Utils;

public class Vars {
    public static int iconHeight;
    public static int screenWidth;
    public static int screenHeight;
    public static String currentDate;
    public static String deviceName;
    public static String deviceType = "a";
    public static String deviceId;
    public static String deviceIpAdress;
    public static String deviceToken;
    public static String IMAGE_DIRECTORY_NAME = "TruckBhejoB2B";
    public static int isNotification = 0;
}
